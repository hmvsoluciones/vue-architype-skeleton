import firebase from 'firebase/app'
import 'firebase/auth'
import 'firebase/firestore'
import 'firebase/storage'

/*
	COLOCA TUS CREDENCIALES DE FIREBASE AQUI
*/
export default firebase