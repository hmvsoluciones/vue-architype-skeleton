<template>
  <h1>HOME PAGE</h1>
</template>

<script>
import { isLogged } from '../../vuex/getters'

export default {
  route: {
    activate: function (transition) {
      if (!this.logged) {
        transition.redirect('/login')
      } else {
        transition.next()
      }
    }
  },
  vuex: {
    getters: {
      logged: isLogged
    }
  }
}
</script>

<style scoped>
</style>
