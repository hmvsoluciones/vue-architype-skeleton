<template>
  <div class="form">
    <p>{{ labels.login.info }}</p>
    <div class="fields">
      <fieldset>
        <legend>{{ labels.login.user }}</legend>
        <input id="login" v-model="login"/>
      </fieldset>
      <fieldset>
        <legend>{{ labels.login.password }}</legend>
        <input id="password" v-model="password" type="password"/>
      </fieldset>
    </div>
    <button
            id="submit"
            type="submit"
            v-on:click="submit"
            v-bind:disabled="submitDisabled">
      {{ labels.login.submit }}
    </button>
  </div>
</template>

<script>
  import {hasContent} from 'src/libs/strings'
  import { login } from '../../vuex/actions'
  import { getLabels } from '../../vuex/getters'

  export default {
    data: function () {
      return {
        login: '',
        password: ''
      }
    },
    methods: {
      submit: function () {
        let msg = JSON.stringify({
          login: this.login,
          password: this.password
        })
        console.log('msg : ' + msg)
        this.doLogin(msg, () => this.$route.router.go('/'), () => console.log('error'))
      }
    },
    computed: {
      submitDisabled: function () {
        var result = true
        if (hasContent(this.login) &&
            hasContent(this.password)
        ) {
          result = false
        }
        return result
      }
    },
    vuex: {
      actions: {
        doLogin: login
      },
      getters: {
        labels: getLabels
      }
    }
  }
</script>

<style scoped>
</style>
