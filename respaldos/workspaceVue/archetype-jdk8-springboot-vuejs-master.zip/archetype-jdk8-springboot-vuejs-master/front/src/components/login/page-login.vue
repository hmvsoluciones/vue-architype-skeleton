<template>
  <div>
    <h1>LOGIN PAGE</h1>
    <login-form></login-form>
  </div>
</template>

<script>
  import LoginForm from './login-form'
  import { getLabels, isLogged } from '../../vuex/getters'

  export default {
    components: {
      LoginForm
    },
    route: {
      activate: function (transition) {
        if (this.logged) {
          transition.redirect('/')
        } else {
          transition.next()
        }
      }
    },
    vuex: {
      getters: {
        labels: getLabels,
        logged: isLogged
      }
    }
  }
</script>

<style scoped>
</style>
