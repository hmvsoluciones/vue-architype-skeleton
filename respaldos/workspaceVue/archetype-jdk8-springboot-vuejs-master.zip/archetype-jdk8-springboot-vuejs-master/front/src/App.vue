<template>
  <div id="app">
    <router-view name="app"></router-view>
    <div>{{ labels.about.contact }} | {{ labels.about.version }}<div>
  </div>
</template>

<script>
import store from './vuex/store'
import { loadLabels } from './vuex/actions'
import { getLabels } from './vuex/getters'

export default {
  replace: false,
  store: store,
  created: function () {
    this.loadLabels()
  },
  vuex: {
    actions: {
      loadLabels: loadLabels
    },
    getters: {
      labels: getLabels
    }
  }
}
</script>

<style>
</style>
